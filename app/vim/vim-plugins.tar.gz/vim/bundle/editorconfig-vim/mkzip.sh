#!/bin/sh

zip -r editorconfig-vim-$*.zip plugin/editorconfig.vim plugin/editorconfig-core-py/* doc/editorconfig.txt autoload/*.vim
